The Reykjavik University Question-Answering Dataset (RUQuAD) is a corpus which contains question/answer (QA) pairs.
Each question is associated with a paragraph in which an answer to the given question is marked. Version 22.02 of RUQuAD consists of approximately 20,800 questions and 12,700 answers.
The corpus data was collected in 2021-2022 by about 1,000 crowd-workers using the GameQA mobile app platform (https://gameqa.app/).
The answers were sourced from five sources in four separate domains: The Icelandic Wikipedia, The Icelandic Web of Science ("Vísindavefurinn"), the news websites mbl.is and visir.is, and The Icelandic Government Information website ("Stjórnarráðið").
The corpus is intended as a training corpus for developing QA models for Icelandic. Note that the answers in this version of RUQuAD have NOT been post-edited/standardized.

The corpus is divided into two parts: RUQuAD-1 and RUQuAD-2.
RUQuAD-1 contains paragraphs from all the above sources EXCEPT The Icelandic Web of Science and can be used with a CC BY license.
The paragraphs in RUQuAD-2 are ONLY collected from The Icelandic Web of Science and can be used with a special license (developed by the Arni Magnusson Institute for Icelandic Studies) which allows the underlying data to be used for linguistic research and the development of language technology, but cannot by licensed with CC BY.

This README.txt is associated with RUQuAD-2.
RUQuAD-2 contains 2,273 questions, of which 2,273 have an associated answer.

The description for the keys in the of the .json file are the following:

There are three files:
full_dataset.json: All the data.
train.json: The part (80%) of the data intended for training.
test.json: The part (20%) of the data intended for testing.

The description for the keys in the .json files are the following:
"question": The question asked
"paragraph": The paragraph containing the answer
"type": Answer type (ANSWERED_WITH_SPAN, ANSWERED_YES_NO, or UNANSWERED_QUESTION)
"start": "The offset inside the paragraph denoting the start of the answer" (for ANSWERED_WITH_SPAN)
"end": The offset inside the paragraph denoting the end of the answer" (for ANSWERED_WITH_SPAN)
"span": The characters comprising the answer from "start" to "end" (for ANSWERED_WITH_SPAN)
"answer": true or false (for ANSWERED_YES_NO)
"question_id": A unique id for the question
"answer_id": A unique id for the answer
"source": The source in which the answer was found
